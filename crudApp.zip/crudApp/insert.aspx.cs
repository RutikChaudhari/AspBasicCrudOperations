﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace crudApp
{
    public partial class insert : System.Web.UI.Page
    {
        // db connection string //
        String ConString = ConfigurationManager.ConnectionStrings["DBconstring"].ConnectionString;
        // db conn //

        String name, city, email, phone, dob, package = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            name = Request.QueryString["n"].ToString();
            city = Request.QueryString["c"].ToString();
            email = Request.QueryString["e"].ToString();
            phone = Request.QueryString["p"].ToString();
            dob = Request.QueryString["dob"].ToString();
            package = Request.QueryString["pkg"].ToString();

            SqlConnection con = new SqlConnection(ConString);
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into memberdetails(name,city,email,phone,dob,package) values ('" + name.ToString() + "','" + city + "','" + email + "','" + phone + "','" + dob + "','" + package + "')";
            cmd.ExecuteNonQuery();
            con.Close();
        }
    }
}