﻿
function checkage(getage) {
	if (getage) {
		var today = new Date();
		var birthDate = new Date(getage);
		var age = today.getFullYear() - birthDate.getFullYear();
		var m = today.getMonth() - birthDate.getMonth();
		if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
			age--;
		}
		if (age < 18) {
			alert("Minimum age should be 18 !!");
			document.getElementById("gdob").value = "";
			document.getElementById("gdob").focus(); return false;
		}

	}
	else {
		return false;
	}
}



function insertdata() {
	var gym_name = $("#gname").val();
	var gym_city = $("#gcity").val();
	var gym_dob = $("#gdob").val();
	var gym_email = $("#gemail").val();
	var gym_phone = $("#gphone").val();
	var gym_packge = $("#gpackage").val();

	function validate() {
		if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(gym_email))) {
			alert("Enter valid email id !!");
			document.getElementById("gemail").focus();
		}
		else if (!(gym_phone.match(/^\d{10}$/))) {
			alert("Enter valid contact number !!");
		}
		else {
			return true;
		}
	}

	if (gym_name != "" && gym_city != "" && gym_email != "" && gym_phone != "" && gym_packge != "" && gym_dob != "") {
		if (validate()) {
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function () {
				if (this.readyState == 4 && this.status == 200) {
					alert("Member registerd successfully !!");
					location.reload();
				}
			};
			xmlhttp.open("POST", "insert.aspx?n=" + gym_name + "&c=" + gym_city + "&dob=" + gym_dob + "&e=" + gym_email + "&p=" + gym_phone + "&pkg=" + gym_packge, false);
			xmlhttp.send(null);
		}
	}
	else {
		alert("Please enter the mandatory fields !!!");
	}

}